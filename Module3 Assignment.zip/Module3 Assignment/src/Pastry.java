public class Pastry extends Cake {
}
